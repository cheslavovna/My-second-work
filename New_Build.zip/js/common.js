/*------------------------------------------------------------------
	WOW
------------------------------------------------------------------*/

wow = new WOW({
    animateClass: 'animated',
    offset: 100
});
wow.init();

/*------------------------------------------------------------------
	Phone mask
------------------------------------------------------------------*/

jQuery(function($){
   $("#phone").mask("+7(999) 999-9999");
});

/*----------------------------------------------------
  Start Change Menu Bg
----------------------------------------------------*/
$(window).on('scroll', function() {
    if ($(window).scrollTop() > 200) {
        $('.header-top').addClass('menu-bg');
    } else {
        $('.header-top').removeClass('menu-bg');
    }
});
/*------------------------------------------------------------------
  Animation Numbers
 ------------------------------------------------------------------*/
$('.animateNumber').each(function() {
    var num = $(this).attr('data-num');

    var top = $(document).scrollTop() + ($(window).height());
    var pos_top = $(this).offset().top;
    if (top > pos_top && !$(this).hasClass('active')) {
        $(this).addClass('active').animateNumber({
            number: num
        }, 2000);
    }
});
$('.animateProcent').each(function() {
    var num = $(this).attr('data-num');
    var percent_number_step = jQuery.animateNumber.numberStepFactories.append('%');
    var top = $(document).scrollTop() + ($(window).height());
    var pos_top = $(this).offset().top;
    if (top > pos_top && !$(this).hasClass('active')) {
        $(this).addClass('active').animateNumber({
            number: num,
            numberStep: percent_number_step
        }, 2000);
        $(this).css('width', num + '%');
    }
});

/*------------------------------------------------------------------
Smooth scroll
------------------------------------------------------------------*/

  $(document).ready(function(){
    $("a[href*=#]").on("click", function(e){
        var anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $(anchor.attr('href')).offset().top
        }, 999);
        e.preventDefault();
        return false;
    });
});

